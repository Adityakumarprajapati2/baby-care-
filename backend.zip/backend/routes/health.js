const express = require('express');
const router = express.Router();
const Health = require('../models/Health');

router.post('/', async (req, res) => {
  const { symptom, careTip } = req.body;
  const newHealth = new Health({ symptom, careTip });
  await newHealth.save();
  res.status(201).send('Health log saved');
});

router.get('/', async (req, res) => {
  const healthLogs = await Health.find();
  res.json(healthLogs);
});

module.exports = router;
