const express = require('express');
const router = express.Router();
const Medicine = require('../models/Medicine');

router.post('/', async (req, res) => {
  const { name, time } = req.body;
  const newMedicine = new Medicine({ name, time });
  await newMedicine.save();
  res.status(201).send('Medicine log saved');
});

router.get('/', async (req, res) => {
  const medicines = await Medicine.find();
  res.json(medicines);
});

module.exports = router;
