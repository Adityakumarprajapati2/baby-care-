const express = require('express');
const router = express.Router();
const Feeding = require('../models/Feeding');

router.post('/', async (req, res) => {
  const { time, type } = req.body;
  const newFeeding = new Feeding({ time, type });
  await newFeeding.save();
  res.status(201).send('Feeding log saved');
});

router.get('/', async (req, res) => {
  const feedings = await Feeding.find();
  res.json(feedings);
});

module.exports = router;
