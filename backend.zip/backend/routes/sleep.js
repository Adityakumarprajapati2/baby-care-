const express = require('express');
const router = express.Router();
const Sleep = require('../models/Sleep');

router.post('/', async (req, res) => {
  const { startTime, endTime } = req.body;
  const newSleep = new Sleep({ startTime, endTime });
  await newSleep.save();
  res.status(201).send('Sleep log saved');
});

router.get('/', async (req, res) => {
  const sleeps = await Sleep.find();
  res.json(sleeps);
});

module.exports = router;
