const express = require('express');
const router = express.Router();
const Diaper = require('../models/Diaper');

router.post('/', async (req, res) => {
  const { time, type } = req.body;
  const newDiaper = new Diaper({ time, type });
  await newDiaper.save();
  res.status(201).send('Diaper log saved');
});

router.get('/', async (req, res) => {
  const diapers = await Diaper.find();
  res.json(diapers);
});

module.exports = router;
