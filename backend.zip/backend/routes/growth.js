const express = require('express');
const router = express.Router();
const Growth = require('../models/Growth');

router.post('/', async (req, res) => {
  const { date, weight, height } = req.body;
  const newGrowth = new Growth({ date, weight, height });
  await newGrowth.save();
  res.status(201).send('Growth log saved');
});

router.get('/', async (req, res) => {
  const growths = await Growth.find();
  res.json(growths);
});

module.exports = router;
