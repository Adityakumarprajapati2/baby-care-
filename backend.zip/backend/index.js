const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb+srv://adityakumar:adi123@mean.2oof4sl.mongodb.net/', {
  //useNewUrlParser: true,
//useUnifiedTopology: true,
}).then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.error("❌ MongoDB connection error:", err));

// Routes Import
const feedingRoutes = require('./routes/feeding');
const sleepRoutes = require('./routes/sleep');
const diaperRoutes = require('./routes/diaper');
const growthRoutes = require('./routes/growth');
const medicineRoutes = require('./routes/medicine');
const healthRoutes = require('./routes/health');

// Use Routes
app.use('/api/feeding', feedingRoutes);
app.use('/api/sleep', sleepRoutes);
app.use('/api/diaper', diaperRoutes);
app.use('/api/growth', growthRoutes);
app.use('/api/medicine', medicineRoutes);
app.use('/api/health', healthRoutes);

// Start Server
app.listen(PORT, () => {
  console.log(`🚀 Server running at: http://localhost:${PORT}`);
});

