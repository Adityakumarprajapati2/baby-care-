const mongoose = require('mongoose');

const MedicineSchema = new mongoose.Schema({
  name: String,
  time: String
});

module.exports = mongoose.model('Medicine', MedicineSchema);
console.log("✅ Medicin route loaded");