const mongoose = require('mongoose');

const SleepSchema = new mongoose.Schema({
  startTime: String,
  endTime: String
});

module.exports = mongoose.model('Sleep', SleepSchema);
console.log("✅ Sleep route loaded");