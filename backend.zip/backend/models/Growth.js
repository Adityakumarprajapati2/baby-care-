const mongoose = require('mongoose');

const GrowthSchema = new mongoose.Schema({
  date: String,
  weight: Number,
  height: Number
});

module.exports = mongoose.model('Growth', GrowthSchema);
console.log("✅ Groath route loaded");