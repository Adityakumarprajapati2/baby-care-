const mongoose = require('mongoose');

const HealthSchema = new mongoose.Schema({
  symptom: String,
  careTip: String
});

module.exports = mongoose.model('Health', HealthSchema);
console.log("✅ Health route loaded");