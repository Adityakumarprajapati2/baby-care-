const mongoose = require('mongoose');

const FeedingSchema = new mongoose.Schema({
  time: String,
  type: String
});

module.exports = mongoose.model('Feeding', FeedingSchema);
console.log("✅ Feeding route loaded");

