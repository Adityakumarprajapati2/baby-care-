const mongoose = require('mongoose');

const DiaperSchema = new mongoose.Schema({
  time: String,
  type: String
});

module.exports = mongoose.model('Diaper', DiaperSchema);
console.log("✅ Diaper route loaded");