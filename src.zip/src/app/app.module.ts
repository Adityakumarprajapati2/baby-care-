import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FeedingComponent } from './baby-care/feeding/feeding.component';
import { SleepComponent } from './baby-care/sleep/sleep.component';
import { DiaperComponent } from './baby-care/diaper/diaper.component';
import { GrowthComponent } from './baby-care/growth/growth.component';
import { MedicineComponent } from './baby-care/medicine/medicine.component';
import { HealthComponent } from './baby-care/health/health.component';
import { FormsModule } from '@angular/forms';
import { SymptomComponent } from './symptom/symptom.component';

@NgModule({
  declarations: [
    AppComponent,
    FeedingComponent,
    SleepComponent,
    DiaperComponent,
    GrowthComponent,
    MedicineComponent,
    HealthComponent,
    SymptomComponent,
   


  ],
  
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }

