import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
    template: `
    <h1>👶 BabyCare+</h1>
    <app-feeding></app-feeding>
    <app-sleep></app-sleep>
    <app-diaper></app-diaper>
    <app-growth></app-growth>
    <app-medicine></app-medicine>
    <app-health></app-health>
  `,
})
export class AppComponent {
  title = 'Baby Care++';
}
