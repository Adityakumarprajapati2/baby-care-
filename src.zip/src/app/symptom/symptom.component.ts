import { Component } from '@angular/core';

@Component({
  selector: 'app-symptom',
  templateUrl: './symptom.component.html',
  styleUrl: './symptom.component.css'
})
export class SymptomComponent {
   symptom = '';
  adviceUrl = '';

  findHelp() {
    if (this.symptom.trim()) {
      this.adviceUrl =
        'https://www.webmd.com/search/search_results/default.aspx?query=' +
        encodeURIComponent(this.symptom + ' kids');
    }
  }

}
