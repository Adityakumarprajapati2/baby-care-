import { Component } from '@angular/core';

@Component({
  selector: 'app-feeding',
  templateUrl: './feeding.component.html',
  styleUrl: './feeding.component.css'
})
export class FeedingComponent {
  feedTime = '';
  feedType = '';
  records: any[] = [];

  addFeeding() {
    this.records.push({ time: this.feedTime, type: this.feedType });
    this.feedTime = '';
    this.feedType = '';
  }

}
