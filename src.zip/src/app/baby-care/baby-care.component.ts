import { Component } from '@angular/core';

@Component({
  selector: 'app-baby-care',
  templateUrl: './baby-care.component.html',
  styleUrl: './baby-care.component.css'
})
export class BabyCareComponent {

}
