import { Component } from '@angular/core';

@Component({
  selector: 'app-health',
  templateUrl: './health.component.html',
  styleUrl: './health.component.css'
})
export class HealthComponent {
  symptom = '';
  tips = '';
  logs: any[] = [];

  addHealth() {
    this.logs.push({ symptom: this.symptom, tips: this.tips });
    this.symptom = '';
    this.tips = '';
  }

}
