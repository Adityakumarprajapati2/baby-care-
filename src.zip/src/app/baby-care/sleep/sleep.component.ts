import { Component } from '@angular/core';

@Component({
  selector: 'app-sleep',
  templateUrl: './sleep.component.html',
  styleUrl: './sleep.component.css'
})
export class SleepComponent {
  start = '';
  end = '';
  naps: any[] = [];

  addSleep() {
    this.naps.push({ start: this.start, end: this.end });
    this.start = '';
    this.end = '';
  }

}
