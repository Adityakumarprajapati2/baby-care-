import { Component } from '@angular/core';

@Component({
  selector: 'app-medicine',
  templateUrl: './medicine.component.html',
  styleUrl: './medicine.component.css'
})
export class MedicineComponent {
  name = '';
  time = '';
  doses: any[] = [];

  addMedicine() {
    this.doses.push({ name: this.name, time: this.time });
    this.name = '';
    this.time = '';
  }
}
