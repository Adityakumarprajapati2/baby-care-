import { Component } from '@angular/core';

@Component({
  selector: 'app-diaper',
  templateUrl: './diaper.component.html',
  styleUrl: './diaper.component.css'
})
export class DiaperComponent {
  time = '';
  type = '';
  changes: any[] = [];

  addChange() {
    this.changes.push({ time: this.time, type: this.type });
    this.time = '';
    this.type = '';
  }

}
