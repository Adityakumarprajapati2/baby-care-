import { Component } from '@angular/core';

@Component({
  selector: 'app-growth',
  templateUrl: './growth.component.html',
  styleUrl: './growth.component.css'
})
export class GrowthComponent {
   date = '';
  weight = '';
  height = '';
  records: any[] = [];

  addGrowth() {
    this.records.push({ date: this.date, weight: this.weight, height: this.height });
    this.date = '';
    this.weight = '';
    this.height = '';
  }

}
